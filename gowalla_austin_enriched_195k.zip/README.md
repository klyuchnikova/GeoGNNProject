# Gowalla Austin enriched subset

Files:

- `gowalla_austin_checkins.csv.gz`: 195,727 Austin check-ins with raw user/POI IDs, UTC timestamp, coordinates and normalized POI category.
- `gowalla_austin_friendships.csv.gz`: friendship edges restricted to users represented in the subset.
- `manifest.json`: counts, provenance and coverage.

The check-in table was produced from SNAP Gowalla check-ins, enriched by a left join with Figshare spot metadata on the original Gowalla POI identifier, then restricted to the Austin metro coordinate box. Missing categories are stored as `__unknown__`.

This archive contains no train/validation/test labels and no remapped IDs. The project performs its own iterative filtering, ID mapping and chronological split, which makes the file reusable across experiment configurations.
